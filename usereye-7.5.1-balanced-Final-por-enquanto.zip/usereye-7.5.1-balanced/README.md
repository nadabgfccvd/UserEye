# UserEye 7.5.1 — delivery bundle

**Start here → [`CURRENT.md`](CURRENT.md).** Documentação do produto: [`UserEye/docs/README.md`](UserEye/docs/README.md).

Uma pasta de docs: `UserEye/docs/`.

| Ler | Para |
| --- | --- |
| [`CURRENT.md`](CURRENT.md) | Versão, testes, 60 s |
| [`DELIVERY.md`](DELIVERY.md) | Inventário e runbook (gates) |
| [`UserEye/README.md`](UserEye/README.md) | Manual do produto |
| [`UserEye/docs/README.md`](UserEye/docs/README.md) | Índice da documentação fundida |
| [`UserEye/docs/CLI.md`](UserEye/docs/CLI.md) | Comandos e flags |
| [`UserEye/docs/ARCHITECTURE.md`](UserEye/docs/ARCHITECTURE.md) | Código e fluxo |
| [`UserEye/docs/CHANGELOG.md`](UserEye/docs/CHANGELOG.md) | Histórico |
| [`UserEye/docs/AUDITS.md`](UserEye/docs/AUDITS.md) | Auditorias e evidência |
| [`UserEye/docs/ROADMAP.md`](UserEye/docs/ROADMAP.md) | Roadmaps |
| [`UserEye/docs/OPERATIONS.md`](UserEye/docs/OPERATIONS.md) | CURRENT+DELIVERY fundidos |

```text
UserEye/   pacote npm + docs/
demo/      harness (não publicado)
```

```bash
cd UserEye && npm ci && npx playwright install chromium && npm test
node ../demo/live-server.js
node bin/usereye.js auto --url http://127.0.0.1:4200/vela/ --mode quick
```

MIT. Node.js >= 20.11.
